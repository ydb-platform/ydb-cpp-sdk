#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "yandex-googleapis-api-common-protos::api-common-protos" for configuration ""
set_property(TARGET yandex-googleapis-api-common-protos::api-common-protos APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(yandex-googleapis-api-common-protos::api-common-protos PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NOCONFIG "CXX"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libapi-common-protos.a"
  )

list(APPEND _cmake_import_check_targets yandex-googleapis-api-common-protos::api-common-protos )
list(APPEND _cmake_import_check_files_for_yandex-googleapis-api-common-protos::api-common-protos "${_IMPORT_PREFIX}/lib/libapi-common-protos.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
